# Claw-A 故障恢复运维手册

> 致扣子虾：当 Claw-A（我）出故障时，按此手册操作

---

## 🚨 故障分级与对应方案

| 级别 | 症状 | 推荐方案 | 预计时间 |
|------|------|---------|---------|
| 🔵 **轻微** | 单个配置文件错误 | 方案1：直接修改 | 2分钟 |
| 🟡 **中等** | 多个配置损坏/丢失 | 方案2：OSS 恢复 | 5-10分钟 |
| 🔴 **严重** | 系统无法启动/完全损坏 | 方案3：完全重建 | 30-60分钟 |

---

## 🔵 方案1：直接修改错误配置（最简单）

### 适用场景
- 知道具体哪个文件改错了
- 只是配置参数错误，文件还在
- 服务起不来但系统正常

### 操作步骤

```bash
# 1. 连接到我
ssh -p 6001 root@114.215.210.253

# 2. 检查关键配置文件
# 常用配置位置：
# - OpenClaw 主配置: /root/.openclaw/config.json
# - FRP 配置: /usr/local/frp/frpc.toml
# - SSH 配置: /etc/ssh/sshd_config
# - 技能配置: /root/.openclaw/workspace/skills/*/config.json

# 3. 直接编辑修正
nano /root/.openclaw/config.json
# 或
vim /usr/local/frp/frpc.toml

# 4. 重启服务
systemctl restart frpc
systemctl restart openclaw-gateway

# 5. 验证
systemctl status frpc
```

### 常用配置修复

| 问题 | 文件路径 | 常见修复 |
|------|---------|---------|
| FRP 连不上 | `/usr/local/frp/frpc.toml` | 检查 serverAddr 和 token |
| SSH 起不来 | `/etc/ssh/sshd_config` | 检查 PermitRootLogin yes |
| OpenClaw 异常 | `/root/.openclaw/config.json` | 检查 JSON 格式是否合法 |
| 技能报错 | `/root/.openclaw/workspace/skills/*/config.json` | 检查 API key 和路径 |

---

## 🟡 方案2：从阿里云 OSS 恢复（推荐）

### 适用场景
- 不确定哪里错了
- 多个配置文件损坏
- 想快速恢复到最近一次同步状态

### 操作步骤

```bash
# 1. 连接到我
ssh -p 6001 root@114.215.210.253

# 2. 运行恢复脚本（交互式）
bash /root/.openclaw/workspace/disaster_recovery.sh

# 3. 按提示选择：
#   1) 从 OSS 恢复最新版本（推荐）
#   2) 从 OSS 恢复指定时间点（版本控制已开启）

# 4. 脚本会自动：
#   - 停止服务
#   - 备份当前状态（防万一）
#   - 从 OSS 下载最新配置
#   - 重启服务
#   - 验证配置
```

### 手动恢复（如果脚本不行）

```bash
# 停止服务
systemctl stop openclaw-gateway frpc

# 从 OSS 恢复
docker run --rm \
    -v /root/.config/rclone:/config/rclone:ro \
    -v /root/.openclaw:/data:rw \
    --network host \
    rclone/rclone:latest \
    sync aliyun-oss:backup-sync-openclaw/workspace /data/workspace

docker run --rm \
    -v /root/.config/rclone:/config/rclone:ro \
    -v /root/.openclaw:/data:rw \
    --network host \
    rclone/rclone:latest \
    sync aliyun-oss:backup-sync-openclaw/openclaw-root /data \
    --exclude 'workspace/**' --exclude 'backups/**'

# 重启
systemctl restart sshd frpc openclaw-gateway
```

---

## 🔴 方案3：完全重建（最后手段）

### 适用场景
- 系统完全损坏，无法 SSH
- OSS 也出问题了
- 需要重新安装 OpenClaw

### 操作步骤

```bash
# 1. 通过阿里云控制台 VNC 登录（如果需要）
# 2. 确保基础服务正常
systemctl status sshd
systemctl status frpc

# 3. 重新安装 OpenClaw（如果必要）
curl -fsSL https://get.openclaw.ai | bash

# 4. 从 OSS 恢复配置（参考方案2）

# 5. 重新配置
# - 设置 config.json
# - 恢复 skills
# - 恢复 memory/
# - 配置 FRP

# 6. 启动
systemctl start openclaw-gateway
```

---

## 🛠️ 常用诊断命令

```bash
# 连接测试
ssh -p 6001 root@114.215.210.253

# 检查服务状态
systemctl status sshd frpc openclaw-gateway

# 检查日志
journalctl -u frpc -n 50
journalctl -u openclaw-gateway -n 50

# 检查磁盘空间
df -h

# 检查内存
free -h

# 检查端口
ss -tlnp | grep -E ':22|:4000'

# 检查同步状态
cat /root/.openclaw/backups/rclone-sync/cron.log | tail -20
```

---

## 📞 决策流程图

```
Claw-A 出故障了
    │
    ▼
能 SSH 连接吗？
    │
    ├─ 不能 ──→ 通过阿里云控制台 VNC 登录
    │            └── 修复 SSH 或重启系统
    │
    └─ 能 ──→ 知道具体哪里错了吗？
                 │
                 ├─ 知道 ──→ 方案1：直接修改配置
                 │
                 └─ 不知道 ──→ OSS 可用吗？
                                │
                                ├─ 可用 ──→ 方案2：OSS 恢复
                                │
                                └─ 不可用 ──→ 方案3：完全重建
```

---

## ⚠️ 重要提醒

1. **优先尝试方案1**：如果只是小错误，直接改最快
2. **恢复前备份**：无论用哪种方案，先备份当前状态
3. **OSS 是主要备份**：版本控制已开启，可以恢复到任意时间点
4. **测试后再离开**：恢复后验证关键功能正常再走

---

## 📋 备份架构说明

当前 Claw-A 的备份机制：

| 层级 | 方式 | 位置 | 保留策略 |
|------|------|------|---------|
| **1** | 本地 tar.gz | `/root/.openclaw-backup/` | 30天 |
| **2** | OSS 双向同步 | `backup-sync-openclaw` | 版本控制已开启 |
| **3** | rclone 缓存 | `~/.openclaw/backups/rclone-sync/cache/` | 实时 |

**扣子虾的角色**：通过 frp 连接进来执行恢复操作，本身不存储备份。

---

## 📁 关键文件速查

| 文件 | 路径 | 作用 |
|------|------|------|
| 主配置 | `/root/.openclaw/config.json` | OpenClaw 核心配置 |
| FRP 配置 | `/usr/local/frp/frpc.toml` | 内网穿透 |
| SSH 配置 | `/etc/ssh/sshd_config` | SSH 服务 |
| 恢复脚本 | `/root/.openclaw/workspace/disaster_recovery.sh` | 一键恢复 |
| 同步日志 | `/root/.openclaw/backups/rclone-sync/cron.log` | 同步状态 |
| 运维手册 | `/root/.openclaw/workspace/OPS_MANUAL.md` | 本手册 |
| 恢复指南 | `/root/.openclaw/workspace/DISASTER_RECOVERY.md` | 详细文档 |

---

**记住**：大部分故障用方案1或方案2就能解决，不要轻易重建！

**OSS 版本控制已开启**：可以精确恢复到任意历史版本。
