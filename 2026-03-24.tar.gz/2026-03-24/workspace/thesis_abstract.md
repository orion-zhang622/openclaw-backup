# 美的集团并购小天鹅财务绩效研究

**学生姓名**：陈亚雯  
**学号**：2408302  
**专业**：财务管理  
**指导教师**：孔文举  
**完成日期**：2026年3月

---

## 摘要

在中国家电行业进入存量竞争时代的背景下，并购整合已成为龙头企业实现战略升级的重要途径。本文以美的集团并购小天鹅为研究对象，基于协同效应理论和规模经济理论，运用财务指标分析法和杜邦分析体系，对并购后的财务绩效进行系统评价。

研究发现，美的集团并购小天鹅后整体财务表现稳健，2021-2024年营业收入年均增长5.9%，净利润年均增长10.4%，销售毛利率和净利率持续改善。但与主要竞争对手相比，仍存在营运效率与规模扩张失衡、盈利质量与协同深化不足、短期偿债压力与流动性偏紧等问题。具体表现为：总资产周转率持续下滑、存货和应收账款周转效率下降、毛利率低于海尔智家和格力电器、洗衣机业务协同效应有待深化、高端化进程相对滞后、短期偿债指标偏低等。

针对上述问题，本文提出以下对策建议：一是优化营运效率，通过数字化管控库存与应收、优化资产结构与处置低效资产，提升总资产周转率；二是深化盈利协同，通过双品牌差异化与高端化布局、研发与供应链协同降本增效，提升毛利率和净利率；三是缓解偿债压力，通过重构债务结构降低短期风险、强化流动性与现金流管控，改善短期偿债能力。

本研究为美的集团深化并购整合成效提供决策参考，也为家电行业同类并购活动的价值创造与风险规避提供理论借鉴与实践启示。

**关键词**：美的集团；小天鹅；并购；财务绩效；协同效应

---

## Abstract

Under the background of China's home appliance industry entering the era of stock competition, merger and acquisition integration has become an important way for leading enterprises to achieve strategic upgrading. This paper takes Midea Group's acquisition of Little Swan as the research object, and systematically evaluates the financial performance after the merger and acquisition based on synergy effect theory and economies of scale theory, using financial indicator analysis method and DuPont analysis system.

The study finds that Midea Group's overall financial performance remains stable after the acquisition, with operating revenue growing at an average annual rate of 5.9% from 2021 to 2024, net profit growing at an average annual rate of 10.4%, and gross profit margin and net profit margin continuing to improve. However, compared with major competitors, there are still problems such as imbalance between operational efficiency and scale expansion, insufficient profit quality and synergy deepening, and short-term debt pressure and tight liquidity. Specifically: continuous decline in total asset turnover, decreased efficiency in inventory and accounts receivable turnover, gross profit margin lower than Haier Smart Home and Gree Electric, synergy effect of washing machine business to be deepened, relatively lagging high-end process, and low short-term debt indicators.

In response to the above problems, this paper puts forward the following countermeasures and suggestions: first, optimize operational efficiency, improve total asset turnover through digital control of inventory and receivables, optimize asset structure and dispose of inefficient assets; second, deepen profit synergy, improve gross profit margin and net profit margin through dual-brand differentiation and high-end layout, R&D and supply chain synergy to reduce costs and increase efficiency; third, alleviate debt pressure, improve short-term debt-paying ability by reconstructing debt structure to reduce short-term risks and strengthening liquidity and cash flow control.

This study provides decision-making reference for Midea Group to deepen the effectiveness of merger and acquisition integration, and also provides theoretical reference and practical enlightenment for value creation and risk avoidance of similar merger and acquisition activities in the home appliance industry.

**Keywords**: Midea Group; Little Swan; Merger and Acquisition; Financial Performance; Synergy Effect

