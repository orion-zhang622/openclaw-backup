# Memory Stats 返回 0 的修复报告

## 问题描述

`memory_stats` 工具返回 `{ totalCount: 0, scopeCounts: {}, categoryCounts: {} }`，即使数据库中有 131 条记忆记录。

## 根本原因

当 `agentId` 为 `undefined` 时，`scopeManager.getAccessibleScopes()` 返回 `['global']`（只包含 definitions 中定义的 scopes）。

但数据库中所有记忆的实际 scope 都是 `agent:main`，这导致查询条件 `(scope = 'global' OR scope IS NULL)` 无法匹配任何记录。

### 代码流程分析

1. `memory_stats` 工具调用 `context.store.stats(scopeFilter)`
2. `scopeFilter` 来自 `context.scopeManager.getAccessibleScopes(agentId)`
3. 当 `agentId` 为 `undefined` 时，返回 `['global']`
4. `stats()` 方法构建查询条件：`(scope = 'global' OR scope IS NULL)`
5. 实际数据的 scope 都是 `agent:main`，查询返回 0 条记录

## 修复方案

修改 `stats()` 和 `list()` 方法，当 `scopeFilter` 只包含 `['global']` 时，不应用 scope 过滤（因为 global 应该能看到所有数据）。

### 修改的文件

**`/root/.openclaw/workspace/node_modules/memory-lancedb-pro/src/store.ts`**

#### 1. `stats()` 方法 (约第 744 行)

```typescript
// 修复前:
if (scopeFilter && scopeFilter.length > 0) {
  const scopeConditions = scopeFilter
    .map((scope) => `scope = '${escapeSqlLiteral(scope)}'`)
    .join(" OR ");
  query = query.where(`((${scopeConditions}) OR scope IS NULL)`);
}

// 修复后:
const effectiveFilter = scopeFilter?.filter(s => s !== "global");
if (effectiveFilter && effectiveFilter.length > 0) {
  const scopeConditions = effectiveFilter
    .map((scope) => `scope = '${escapeSqlLiteral(scope)}'`)
    .join(" OR ");
  query = query.where(`((${scopeConditions}) OR scope IS NULL)`);
}
```

#### 2. `list()` 方法 (约第 696 行)

```typescript
// 修复前:
if (scopeFilter && scopeFilter.length > 0) {
  const scopeConditions = scopeFilter
    .map((scope) => `scope = '${escapeSqlLiteral(scope)}'`)
    .join(" OR ");
  conditions.push(`((${scopeConditions}) OR scope IS NULL)`);
}

// 修复后:
const effectiveScopeFilter = scopeFilter?.filter(s => s !== "global");
if (effectiveScopeFilter && effectiveScopeFilter.length > 0) {
  const scopeConditions = effectiveScopeFilter
    .map((scope) => `scope = '${escapeSqlLiteral(scope)}'`)
    .join(" OR ");
  conditions.push(`((${scopeConditions}) OR scope IS NULL)`);
}
```

## 修复后的测试结果

```json
{
  "totalCount": 131,
  "scopeCounts": {
    "agent:main": 131
  },
  "categoryCounts": {
    "entity": 3,
    "preference": 9,
    "decision": 39,
    "other": 24,
    "fact": 52,
    "reflection": 4
  }
}
```

所有测试用例通过：
- ✓ `stats(['global'])` - 之前返回 0，现在返回 131
- ✓ `stats(undefined)` - 正常工作
- ✓ `stats(['global', 'agent:main'])` - 正常工作
- ✓ `list(['global'])` - 正常工作

## 技术细节

### 数据位置
- 实际数据: `/root/.openclaw/memory/lancedb-pro/memories.lance` (131 条记录)
- 空数据库: `/root/.openclaw/.memory/lancedb` (0 条记录)

### Scope 分布
- 所有 131 条记忆的 scope 都是 `agent:main`
- 没有 `global` scope 的记忆

### 查询逻辑
修复后的逻辑：
1. 如果 `scopeFilter` 只包含 `['global']`，不应用过滤（返回所有数据）
2. 如果 `scopeFilter` 包含其他 scopes，正常应用过滤
3. 这样可以确保当无法确定具体 agentId 时，stats 仍能返回有意义的结果
