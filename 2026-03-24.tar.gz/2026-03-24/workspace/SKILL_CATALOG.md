# OpenClaw Skill 功能清单

## 🌐 网络搜索与内容获取

| Skill | 功能 | 使用场景 |
|-------|------|---------|
| **agent-reach** | 16+ 平台内容抓取：Twitter/X, Reddit, YouTube, GitHub, Bilibili, 小红书, 抖音, 微博, 微信文章, 小宇宙播客, LinkedIn, Instagram, V2EX, RSS, Exa 搜索 | 搜索任何平台内容、读取网页、监控社交媒体 |
| **baidu-search** | 百度搜索 API | 国内信息搜索、文档查询 |
| **tavily** | AI 优化搜索，生成答案摘要 | 研究任务、新闻查询、事实核查 |
| **kimi-search** | Kimi 搜索 + 内容提取 | 最新信息查询、网页抓取 |
| **web_fetch** | 网页内容提取（内置）| 快速获取网页正文 |

## 📱 社交媒体运营

| Skill | 功能 | 使用场景 |
|-------|------|---------|
| **post-to-xhs** | 小红书内容发布（图文/视频）| 发布笔记、种草内容 |
| **xhs-search** | 小红书笔记搜索 | 查找攻略、竞品分析 |
| **xhs-explore** | 小红书推荐流浏览 | 养号、查看热门内容 |
| **xhs-interact** | 小红书互动（点赞/收藏/评论）| 账号互动、评论回复 |
| **xhs-login** | 小红书登录管理 | 扫码登录、切换账号 |
| **xhs-profile** | 小红书用户主页查看 | 博主分析、竞品研究 |
| **xhs-content-plan** | 小红书内容策划 | 选题规划、爆款分析 |
| **douyin-download** | 抖音无水印下载 + 文案提取 | 视频下载、内容分析 |
| **bilibili-subtitle-download** | B站字幕下载 + 分块总结 | 视频学习、内容提取 |
| **wechat-article-writer** | 公众号文章自动生成 | 内容创作、自动发布 |

## 🤖 自动化与效率

| Skill | 功能 | 使用场景 |
|-------|------|---------|
| **auto-updater** | 自动更新 OpenClaw 和 Skills | 保持系统最新 |
| **proactive-agent** | 主动式 Agent，预判需求 | 智能提醒、主动建议 |
| **task-planner** | 任务规划与执行指导 | 复杂任务拆解、方案设计 |
| **find-skills** | Skill 搜索与安装 | 发现新能力、扩展功能 |
| **skill-creator** | 创建自定义 Skill | 开发专属功能 |
| **skill-vetter** | Skill 安全审查 | 安装前安全检查 |
| **skillhub-preference** | SkillHub 偏好设置 | 管理 Skill 源 |

## 🧠 记忆与知识管理

| Skill | 功能 | 使用场景 |
|-------|------|---------|
| **memory-lancedb-pro** | 长期记忆系统（向量+关键词混合检索）| 存储偏好、记录决策 |
| **ontology** | 结构化知识图谱 | 实体关系管理、项目关联 |
| **book-ingestion** | 书籍内化（PDF/EPUB）| 知识提取、思维模型 |
| **daily-intelligence** | 每日情报简报生成 | 资讯汇总、行业洞察 |
| **document-handler** | 文档处理 | 文件管理、格式转换 |

## 🎨 内容创作

| Skill | 功能 | 使用场景 |
|-------|------|---------|
| **ppt-generator** | 乔布斯风 HTML 演示稿 | 演讲 PPT、产品发布 |
| **image-gen** | AI 图片生成 | 封面图、配图生成 |
| **humanizer** | 去除 AI 写作痕迹 | 文章润色、降低 AIGC 检测 |
| **humanizer-academic-zh** | 中文学术论文润色 | 论文降重、去除 AI 味 |
| **summarize** | URL/文件/视频总结 | 快速了解内容、生成摘要 |

## 🔧 开发工具

| Skill | 功能 | 使用场景 |
|-------|------|---------|
| **github** | GitHub CLI 操作 | Issue/PR 管理、CI 监控 |
| **agent-browser** | 浏览器自动化（Rust 版）| 网页操作、数据采集 |
| **playwright-mcp** | Playwright 浏览器自动化 | 复杂交互、录制回放 |
| **python-dataviz** | Python 数据可视化 | 图表生成、数据分析 |
| **api-gateway** | 100+ API 统一管理（Maton）| 第三方服务接入 |
| **office** | Excel/Word/PPT 处理 | 文档编辑、报表生成 |

## 💾 存储与云服务

| Skill | 功能 | 使用场景 |
|-------|------|---------|
| **bdpan-storage** | 百度网盘文件管理 | 文件上传/下载/转存 |
| **rclone**（内置）| 多云存储同步 | 备份、同步 |

## 🛠️ 系统管理

| Skill | 功能 | 使用场景 |
|-------|------|---------|
| **model-fallback** | 多模型自动降级 | API 故障时自动切换 |
| **freeride-ai** | 免费 AI 模型管理 | 降低 API 成本 |
| **healthcheck** | 系统安全审计 | 安全检查、加固建议 |
| **setup-xhs-mcp** | 小红书 MCP 服务安装 | 环境搭建、服务配置 |
| **tmux** | Tmux 会话远程控制 | 终端复用、长任务管理 |

## 📊 数据分析

| Skill | 功能 | 使用场景 |
|-------|------|---------|
| **yinan-data-analyzer** | CSV/Excel/JSON 数据分析 | 销售分析、报表生成 |
| **video-frames** | 视频帧提取 | 视频分析、素材提取 |
| **coze-asr** | 语音转文字 | 音频转录、字幕生成 |
| **coze-tts** | 文字转语音 | 语音合成、播报 |

## 🎓 学术研究

| Skill | 功能 | 使用场景 |
|-------|------|---------|
| **thesis-assistant** | 论文辅助写作 | 毕业论文、学术研究 |

## 🌤️ 实用工具

| Skill | 功能 | 使用场景 |
|-------|------|---------|
| **weather** | 天气查询（无需 API Key）| 出行参考、天气提醒 |

## 总计：44 个 Skill

### 按类别统计
- 网络搜索：5 个
- 社交媒体：10 个
- 自动化效率：6 个
- 记忆知识：4 个
- 内容创作：5 个
- 开发工具：6 个
- 存储云服：2 个
- 系统管理：5 个
- 数据分析：4 个
- 学术研究：1 个
- 实用工具：1 个
