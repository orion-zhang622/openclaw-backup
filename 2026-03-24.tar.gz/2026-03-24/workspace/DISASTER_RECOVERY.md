# Claw-A 灾难恢复操作指南

## 📋 场景

当 Claw-A（我）出现故障，需要从备份恢复配置。

---

## 🔄 备份机制

| 项目 | 配置 |
|------|------|
| 同步方式 | rclone bisync 双向同步 |
| 频率 | 每4小时（通过 cron）|
| OSS Bucket | `backup-sync-openclaw` |
| **版本控制** | ✅ **已开启** |

---

## 🔧 恢复流程（扣子虾操作）

### 自动恢复脚本（推荐）

```bash
# 1. 连接到故障的我
ssh -p 6001 root@114.215.210.253

# 2. 运行恢复脚本
bash /root/.openclaw/workspace/disaster_recovery.sh

# 3. 按提示选择:
#    1) 从 OSS 恢复最新版本
#    2) 从 OSS 恢复指定时间点的版本  ← 版本控制已开启
#    3) 从扣子虾本地备份恢复
```

---

## 📅 版本控制恢复说明

### ✅ 已开启 OSS 版本控制

Bucket `backup-sync-openclaw` 已开启版本控制，所有历史版本都被保留。

### 恢复方式对比

| 方式 | 精度 | 操作难度 | 适用场景 |
|------|------|---------|---------|
| **脚本近似恢复** | 按修改时间 | 简单 | 快速恢复大体版本 |
| **控制台精确恢复** | 按版本 ID | 中等 | 精确恢复到某次修改 |
| **下载单个文件** | 按版本 ID | 手动 | 只恢复特定配置文件 |

---

## 🎯 精确版本恢复（阿里云控制台）

如果需要**精确**恢复到特定版本：

### 步骤 1：登录控制台
1. 打开 [阿里云 OSS 控制台](https://oss.console.aliyun.com/)
2. 选择 Bucket: `backup-sync-openclaw`
3. 进入「文件管理」

### 步骤 2：选择文件版本
1. 找到需要恢复的文件/目录
2. 点击「版本管理」或「历史版本」
3. 查看所有历史版本列表
4. 选择特定时间点的版本

### 步骤 3：恢复文件
- **单文件**: 点击「下载」获取历史版本
- **批量恢复**: 使用 ossutil 命令行工具

```bash
# 使用 ossutil 恢复特定版本（示例）
ossutil cp oss://backup-sync-openclaw/workspace/SOUL.md \
           --version-id CAEQMxiBgICA8.aBphciIDUyZWI0Y2I3ZTU3... \
           /root/.openclaw/workspace/SOUL.md
```

---

## 📁 关键路径

| 类型 | 路径 |
|------|------|
| 恢复脚本 | `/root/.openclaw/workspace/disaster_recovery.sh` |
| 同步脚本 | `/root/.openclaw/backups/rclone-sync/sync.sh` |
| rclone 配置 | `/root/.config/rclone/rclone.conf` |
| OSS Bucket | `backup-sync-openclaw` |

---

## 📝 更新记录

- 2026-03-22: 更新支持 OSS 版本控制恢复
- 2026-03-22: 添加精确版本恢复说明
